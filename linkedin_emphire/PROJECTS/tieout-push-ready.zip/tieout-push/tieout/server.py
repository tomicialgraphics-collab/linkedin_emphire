"""FastAPI server: bundle browser + stranger verify over HTTP.

The UI is a viewer for tieout's own evidence bundles, not an LLM
observability dashboard: it renders the record and runs the P5
re-derivation. Bind to 0.0.0.0 when the port is published.
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles

from . import __version__
from .bundle.verify import verify_bundle
from .harness import get_family, list_families
from .mappings import ASI_CROSSWALK, F1_PROPOSED_MAPPING


def create_app(runs_dir: str | Path) -> FastAPI:
    runs_dir = Path(runs_dir)
    app = FastAPI(title="tieout", version=__version__)

    def _load(run_id: str):
        d = runs_dir / run_id
        if not d.is_dir() or not (d / "bundle.jsonl").exists():
            raise HTTPException(status_code=404, detail=f"run {run_id!r} not found")
        lines = [
            json.loads(line)
            for line in (d / "bundle.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        manifest = lines[0]
        rest = lines[1:]
        return (
            d,
            manifest,
            [ln for ln in rest if ln.get("type") == "event"],
            [ln for ln in rest if ln.get("type") == "control"],
            next((ln for ln in rest if ln.get("type") == "judge_audit"), None),
            [ln for ln in rest if ln.get("type") == "gap"],
        )

    @app.get("/api/health")
    def health() -> dict:
        return {"ok": True, "version": __version__}

    @app.get("/api/runs")
    def runs() -> list[dict]:
        out = []
        if runs_dir.exists():
            for d in sorted(runs_dir.iterdir()):
                if not (d / "bundle.jsonl").exists():
                    continue
                _, manifest, events, controls, _audit, gaps = _load(d.name)
                verdicts: dict[str, int] = {}
                for e in events:
                    verdicts[e["decision"]] = verdicts.get(e["decision"], 0) + 1
                out.append(
                    {
                        "id": d.name,
                        "run_id": manifest.get("run_id"),
                        "agent": manifest.get("provenance", {}).get("agent"),
                        "suite": manifest.get("provenance", {}).get("suite"),
                        "started_at": manifest.get("provenance", {}).get("started_at"),
                        "events": len(events),
                        "controls": len(controls),
                        "verdicts": verdicts,
                        "controls_fp": manifest.get("controls_fp", 0),
                        "controls_fn": manifest.get("controls_fn", 0),
                        "gaps": len(gaps),
                    }
                )
        return out

    @app.get("/api/runs/{run_id}")
    def run_detail(run_id: str) -> dict:
        d, manifest, events, controls, audit, gaps = _load(run_id)
        return {
            "id": d.name,
            "manifest": manifest,
            "events": events,
            "controls": controls,
            "judge_audit": audit,
            "gaps": gaps,
        }

    @app.post("/api/runs/{run_id}/verify")
    def verify_run(run_id: str) -> dict:
        d, manifest, events, controls, _audit, _gaps = _load(run_id)
        fam_id = events[0].get("family") if events else None
        family = get_family(fam_id) if fam_id else None
        res = verify_bundle(d, family=family)
        report = {
            "lines": res.lines,
            "gaps": [g.model_dump() for g in res.gaps],
            "verdict": res.verdict,
            "ok": res.ok,
        }
        (d / "verify_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        return report

    @app.get("/api/families")
    def families() -> list[dict]:
        return [
            {
                "family_id": f.family_id,
                "name": f.name,
                "policy_label": f.policy_label,
                "policy_version": f.policy_version,
                "items": len(f.items),
                "controls": len(f.controls),
                "item_ids": f.item_ids(),
            }
            for f in list_families()
        ]

    @app.get("/api/asi")
    def asi() -> dict:
        return {"crosswalk": ASI_CROSSWALK, "f1_proposed": F1_PROPOSED_MAPPING}

    dist = Path(__file__).resolve().parent.parent / "web" / "out"
    if dist.exists():
        app.mount("/", StaticFiles(directory=dist, html=True), name="ui")
    return app
